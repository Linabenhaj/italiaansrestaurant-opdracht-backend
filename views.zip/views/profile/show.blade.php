<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Profiel van {{ $user->username }} - Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>

<header style="background-color: #8B0000; color: white; padding: 1rem; text-align: center;">
    <h1 style="margin: 0; font-family: 'Sigmar One', cursive;">Pizzeria Antonio</h1>
</header>

<nav class="navigation" style="background-color: rgb(255, 207, 207); padding: 1rem; border-radius: 0;">
    <div class="nav-container" style="display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto;">
        <img src="{{ asset('images/pizzerialogo.png') }}" alt="Logo" style="height: 100px; border-radius: 0;">

        <ul class="nav-links" style="list-style: none; display: flex; gap: 1.5rem; margin: 0; padding: 0;">
            <li><a href="{{ url('/') }}" style="text-decoration: none; color: #8B0000; font-weight: 600;">Home</a></li>

            @auth
                <li><a href="{{ url('/profile/' . Auth::user()->username) }}" style="text-decoration: none; color: #8B0000;">Mijn Profiel</a></li>
                <li><a href="{{ url('/orders') }}" style="text-decoration: none; color: #8B0000;">Mijn Bestellingen</a></li>
                <li>
                    <a href="{{ route('logout') }}" style="text-decoration: none; color: #8B0000;"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </li>
            @else
                <li><a href="{{ route('login') }}" style="text-decoration: none; color: #8B0000;">Login</a></li>
                <li><a href="{{ route('register') }}" style="text-decoration: none; color: #8B0000;">Register</a></li>
            @endauth
        </ul>
    </div>
</nav>

@if(session('success'))
    <div style="color: green; margin-bottom: 1rem;">
        {{ session('success') }}
    </div>
@endif

<body style="font-family: 'Outfit', sans-serif; background-color: #fff7d4; margin: 0; padding: 2rem;">


    <div style="max-width: 600px; margin: 2rem auto; background-color: #fff; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        <h1 style="color: #8B0000;">Profiel van {{ $user->username ?? $user->name }}</h1>

        @if ($user->profile_picture)
            <img
                src="{{ asset('storage/' . $user->profile_picture) }}"
                alt="Profielfoto van {{ $user->username }}"
                style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #8B0000;"
            />
        @else
            <img
                src="{{ asset('images/default-profile.png') }}"
                alt="Standaard profielfoto"
                style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #8B0000;"
            />
        @endif

        <h2 style="color: #8B0000; margin-top: 1.5rem;">Verjaardag:</h2>
        <p>{{ $user->birthday ? \Carbon\Carbon::parse($user->birthday)->format('d-m-Y') : 'Niet opgegeven' }}</p>

        <h2 style="color: #8B0000; margin-top: 1.5rem;">Over mij:</h2>
        <p style="font-style: italic; color: #333;">{{ $user->about ?? 'Deze gebruiker heeft nog geen informatie toegevoegd.' }}</p>

        @auth
            @if (auth()->id() === $user->id)
                <a href="{{ route('profile.edit', $user->username) }}" 
                   style="display: inline-block; margin-top: 1rem; padding: 0.5rem 1rem; background-color: #8B0000; color: white; border-radius: 5px; text-decoration: none;">
                   Profiel aanpassen
                </a>
            @endif
        @endauth
    </div>

</body>
</html>
