<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizzeria Antonio</title>

    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/styl.css') }}">
</head>
<body style="margin: 0; font-family: 'Outfit', sans-serif; background-color: #fff;">

    <header style="background-color:rgb(255, 152, 152); color: white; padding: 1rem; text-align: center;">
        <h1 style="margin: 0; font-family: 'Sigmar One', cursive;">Pizzeria Antonio</h1>
    </header>

    <nav class="navigation" style="background-color:rgb(255, 207, 207); padding: 1rem;">
        <div class="nav-container" style="display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto;">
            <img src="{{ asset('images/pizzerialogo.png') }}" alt="Logo" style="height: 100px;">
            
            <ul class="nav-links" style="list-style: none; display: flex; gap: 1.5rem; margin: 0; padding: 0;">
                <li><a href="{{ url('/') }}" style="text-decoration: none; color: #8B0000; font-weight: 600;">Home</a></li>
                <li><a href="{{ route('contact.form') }}" style="text-decoration: none; color: #8B0000;">Contact</a></li>
                @auth
                    <li><a href="{{ url('/profile/' . Auth::user()->username) }}" style="text-decoration: none; color: #8B0000;">Mijn Profiel</a></li>
                    <li><a href="{{ route('user.dashboard') }}" style="text-decoration: none; color: #8B0000;">Dashboard</a></li>
                    @if(Auth::user()->user_type === 'admin')
                        <li><a href="{{ route('admin.dashboard') }}" style="text-decoration: none; color: #8B0000;">Admin</a></li>
                    @endif
                    <li>
                        <a href="{{ route('logout') }}" style="text-decoration: none; color: #8B0000;" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </li>
                @else
                    <li><a href="{{ route('login') }}" style="text-decoration: none; color: #8B0000;">Login</a></li>
                    <li><a href="{{ route('register') }}" style="text-decoration: none; color: #8B0000;">Register</a></li>
                @endauth
            </ul>
        </div>
    </nav>

    <section style="padding: 2rem; text-align: center; background-color: #fff;">
        <h2 style="font-size: 2rem; color: #8B0000;">Welkom bij Pizzeria Antonio</h2>
        <p style="font-size: 1.1rem; color: #333;">Proef onze authentieke Italiaanse pizza’s, gemaakt met liefde en passie!</p>
    </section>

    <section style="padding: 2rem; background-color: #fffefe;">
        <h2 style="text-align: center; font-family: 'Sigmar One', cursive; color: #8B0000;">Ons Menu</h2>
        <div class="pizza-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; margin-top: 2rem;">
            @foreach([
                ['pizza_margherita.jpg', 'Margherita', '€8,50'],
                ['pizza_pepperoni.jpg', 'Pepperoni', '€10,00'],
                ['pizza_vegetariana.jpg', 'Vegetariana', '€9,50'],
                ['pizza_quattro_formaggi.jpg', 'Quattro Formaggi', '€11,00'],
                ['pizza_hawaiana.jpg', 'Hawaïana', '€9,00'],
                ['pizza_bbq_chicken.jpg', 'BBQ Chicken', '€11,50'],
            ] as [$image, $name, $price])
                <div class="pizza-card" style="background-color: #fff; border: 1px solid #ccc; border-radius: 10px; padding: 1rem; text-align: center; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
                    <img src="{{ asset('images/' . $image) }}" alt="Pizza {{ $name }}" style="width: 100%; border-radius: 10px;">
                    <h3 style="margin-top: 1rem; font-family: 'Sigmar One', cursive; color: #8B0000;">{{ $name }}</h3>
                    <p style="color: #444;">{{ $price }}</p>
                    @auth
                       <form action="{{ route('orders.store') }}" method="POST">
                            @csrf
                            <input type="hidden" name="pizza" value="{{ $name }}">
                            <button type="submit" style="background-color: #8B0000; color: white; padding: 0.5rem 1rem; border: none; border-radius: 5px; cursor: pointer;">Bestellen</button>
                        </form>
                    @else
                        <a href="{{ route('login') }}">
                            <button style="background-color: #8B0000; color: white; padding: 0.5rem 1rem; border: none; border-radius: 5px; cursor: pointer;">Bestellen</button>
                        </a>
                    @endauth
                </div>
            @endforeach
        </div>
    </section>

    <section style="padding: 2rem; background-color: #fffef6;">
    <h2 style="text-align: center; font-family: 'Sigmar One', cursive; color: #8B0000;">Bestel je favoriete pizza</h2>

    @auth
     <form method="POST" action="{{ route('orders.store') }}" style="max-width: 600px; margin: 2rem auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        @csrf

        <div style="margin-bottom: 1rem;">
            <label for="pizza" style="color: #8B0000; display: block; margin-bottom: 0.5rem;">Kies je pizza</label>
            <select name="pizza" id="pizza" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">
                <option value="">-- Selecteer --</option>
                <option value="Margherita">Margherita</option>
                <option value="Pepperoni">Pepperoni</option>
                <option value="Vegetariana">Vegetariana</option>
                <option value="Quattro Formaggi">Quattro Formaggi</option>
                <option value="BBQ Chicken">BBQ Chicken</option>
            </select>
        </div>

        <div style="margin-bottom: 1rem;">
            <label for="opmerkingen" style="color: #8B0000; display: block; margin-bottom: 0.5rem;">Opmerkingen (optioneel)</label>
            <textarea name="opmerkingen" id="opmerkingen" rows="3" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;"></textarea>
        </div>

        <button type="submit" style="background-color: #8B0000; color: white; padding: 0.6rem 1.5rem; border: none; border-radius: 5px; cursor: pointer;">Bestellen</button>
    </form>
    @else
        <p style="text-align: center; margin-top: 2rem;">Je moet <a href="{{ route('login') }}" style="color: #8B0000; font-weight: bold;">inloggen</a> om een bestelling te plaatsen.</p>
    @endauth
</section>

    <section id="faq" style="padding: 2rem; background-color: #fff;">
        <h2 style="text-align: center; font-family: 'Sigmar One', cursive; color: #8B0000;">Veelgestelde Vragen</h2>

        <div style="max-width: 800px; margin: 2rem auto;">
            @foreach($faqCategories as $category)
                <h3 style="color: #8B0000; margin-top: 2rem;">{{ $category->name }}</h3>
                <ul style="list-style: none; padding-left: 0;">
                    @foreach($category->faqs as $faq)
                        <li style="margin-bottom: 1rem;">
                            <button onclick="toggleAnswer(this)" style="width: 100%; text-align: left; padding: 1rem; border: none; background-color: #ffeaea; color: #8B0000; font-weight: bold; cursor: pointer; border-radius: 5px;">
                                {{ $faq->question }}
                            </button>
                            <div class="faq-answer" style="display: none; padding: 1rem; background-color: #fff5f5; border-left: 4px solid #8B0000;">
                                {{ $faq->answer }}
                            </div>
                        </li>
                    @endforeach
                </ul>
            @endforeach
        </div>

        <script>
            function toggleAnswer(button) {
                const answer = button.nextElementSibling;
                answer.style.display = (answer.style.display === 'block') ? 'none' : 'block';
            }
        </script>

        <hr style="margin: 3rem 0;">
        <div style="max-width: 600px; margin: 0 auto;">
            <h3 style="color: #8B0000;">Heb je een andere vraag?</h3>
            <form action="{{ route('faq.submit') }}" method="POST" style="margin-top: 1rem;">
                @csrf
                <div style="margin-bottom: 1rem;">
                    <label for="email">Emailadres</label><br>
                    <input type="email" name="email" required style="width: 100%; padding: 0.5rem;">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label for="question">Je vraag</label><br>
                    <textarea name="question" rows="4" required style="width: 100%; padding: 0.5rem;"></textarea>
                </div>
                <button type="submit" style="background-color: #8B0000; color: white; padding: 0.5rem 1.5rem; border: none; border-radius: 5px;">Verstuur</button>
            </form>
        </div>
    </section>

<section id="nieuws" style="padding:2rem; background:#fff;">
  <h2 style="color:#8B0000;">Laatste nieuws</h2>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1.5rem;">
    @foreach($newsItems as $item)
      <a href="{{ route('news.show',$item) }}" style="text-decoration:none;color:inherit;">
        <div style="border:1px solid #ccc;border-radius:8px;overflow:hidden;">
          <img src="{{ asset('storage/'.$item->image) }}" alt="" style="width:100%;height:150px;object-fit:cover;">
          <div style="padding:1rem;">
            <h3>{{ $item->title }}</h3>
            <p style="font-size:0.9rem;color:#555;">{{ Str::limit($item->content, 80) }}</p>
            <p style="font-size:0.8rem;color:#999;">{{ $item->published_at->format('d-m-Y') }}</p>
          </div>
        </div>
      </a>
    @endforeach
  </div>
</section>


    <footer class="pizzeria-footer" style="background-color: #8B0000; color: white; padding: 2rem 1rem;">
        <div class="footer-container" style="display: flex; flex-wrap: wrap; justify-content: space-around; max-width: 1200px; margin: 0 auto;">
            <div class="footer-column" style="flex: 1; min-width: 200px; margin: 1rem;">
                <h3 style="color: #F6E27F;">OVER ONS</h3>
                <p>Onze pizzeria staat voor authentieke Italiaanse pizza’s, vers bereid met de beste ingrediënten.<br>
                Gezellige sfeer en heerlijke smaken in het hart van België.</p>
            </div>
            <div class="footer-column" style="flex: 1; min-width: 200px; margin: 1rem;">
                <h3 style="color: #F6E27F;">CONTACT</h3>
                <p>Marktstraat 12<br>1000 Brussel</p>
                <p>+32 2 123 45 67</p>
                <p><a href="mailto:info@jouwpizzeria.be" style="color: #F6E27F; text-decoration: none;">info@jouwpizzeria.be</a></p>
            </div>
            <div class="footer-column" style="flex: 1; min-width: 200px; margin: 1rem;">
                <h3 style="color: #F6E27F;">OPENINGSTIJDEN</h3>
                <p>Maandag: Gesloten</p>
                <p>Di - Za: 11:00 - 22:30</p>
                <p>Zondag: 12:00 - 21:00</p>
            </div>
        </div>
        <div class="footer-bottom" style="margin-top: 2rem; text-align: center; font-size: 0.9rem;">
            <p>© 2025 Pizzeria Antonio | Alle rechten voorbehouden | Design door: Lina Benhaj</p>
        </div>
    </footer>

</body>
</html>
