<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Registreren - Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="background-color: #FFF7D4; font-family: 'Outfit', sans-serif; margin: 0; padding: 0;">
    <div style="max-width: 450px; margin: 5rem auto; background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        <h1 style="text-align: center; color: #8B0000; font-family: 'Sigmar One', cursive;">Registreren</h1>

        @if ($errors->any())
            <div style="background-color: #f8d7da; color: #721c24; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <ul style="margin: 0; padding-left: 1.2rem;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('register') }}">
            @csrf
            <label for="name" style="display: block; margin-top: 1rem; color: #8B0000;">Volledige naam</label>
            <input type="text" name="name" id="name" required value="{{ old('name') }}" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <label for="username" style="display: block; margin-top: 1rem; color: #8B0000;">Gebruikersnaam</label>
            <input type="text" name="username" id="username" required value="{{ old('username') }}" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <label for="email" style="display: block; margin-top: 1rem; color: #8B0000;">E-mailadres</label>
            <input type="email" name="email" id="email" required value="{{ old('email') }}" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <label for="password" style="display: block; margin-top: 1rem; color: #8B0000;">Wachtwoord</label>
            <input type="password" name="password" id="password" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <label for="password_confirmation" style="display: block; margin-top: 1rem; color: #8B0000;">Bevestig wachtwoord</label>
            <input type="password" name="password_confirmation" id="password_confirmation" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <button type="submit" style="margin-top: 1.5rem; width: 100%; background-color: #8B0000; color: white; padding: 0.75rem; border: none; border-radius: 5px; cursor: pointer;">Registreren</button>
        </form>

        <p style="text-align: center; margin-top: 1rem;">
            Al een account? <a href="{{ route('login') }}" style="color: #8B0000; font-weight: bold;">Log hier in</a>
        </p>
    </div>
</body>
</html>