<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Login - Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>


<body style="background-color: #FFF7D4; font-family: 'Outfit', sans-serif; margin: 0; padding: 0;">
    <div style="max-width: 400px; margin: 5rem auto; background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        <h1 style="text-align: center; color: #8B0000; font-family: 'Sigmar One', cursive;">Inloggen</h1>

        @if ($errors->any())
            <div style="background-color: #f8d7da; color: #721c24; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <ul style="margin: 0; padding-left: 1.2rem;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf
            <label for="email" style="display: block; margin-top: 1rem; color: #8B0000;">E-mailadres</label>
            <input type="email" name="email" id="email" required value="{{ old('email') }}" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <label for="password" style="display: block; margin-top: 1rem; color: #8B0000;">Wachtwoord</label>
            <input type="password" name="password" id="password" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 5px;">

            <div style="margin-top: 1rem;">
                <input type="checkbox" name="remember"> Onthoud mij
            </div>

            <button type="submit" style="margin-top: 1rem; width: 100%; background-color: #8B0000; color: white; padding: 0.75rem; border: none; border-radius: 5px; cursor: pointer;">Login</button>
        </form>

        <p style="text-align: center; margin-top: 1rem;">
            Nog geen account? <a href="{{ route('register') }}" style="color: #8B0000; font-weight: bold;">Registreer hier</a>
        </p>
    </div>
</body>
</html>