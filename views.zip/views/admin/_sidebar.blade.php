<aside style="width:220px;background:#8B0000;color:#fff;padding:2rem 1rem;display:flex;flex-direction:column;justify-content:space-between;">
  <div>
    <h2 style="font-family:'Sigmar One',cursive;text-align:center;margin-bottom:2rem;">Admin Panel</h2>
    <nav style="display:flex;flex-direction:column;gap:1rem;">
      <a href="{{ route('admin.dashboard') }}" style="color:white;font-weight:bold;">Dashboard</a>
      <a href="{{ route('admin.users.index') }}" style="color:white;">Gebruikers</a>
      <a href="{{ route('admin.faq.index') }}"   style="color:white;">FAQ</a>
      <a href="{{ route('admin.news.index') }}"  style="color:white;">Nieuws</a>
      <a href="{{ route('admin.orders.index') }}" style="color:white;">Bestellingen</a>
      <a href="{{ route('admin.contact.inbox') }}" style="color:white;">Contact</a>
    </nav>
  </div>
  <form method="POST" action="{{ route('logout') }}">
    @csrf
    <button style="width:100%;background:#F6E27F;color:#8B0000;padding:0.5rem;border:none;border-radius:5px;cursor:pointer;">
      Uitloggen
    </button>
  </form>
</aside>
