<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bestellingen – Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0; font-family:'Outfit',sans-serif; display:flex; height:100vh; background:#FFF7D4;">

  {{-- Sidebar --}}
  <aside style="width:220px; background:#8B0000; color:#fff; padding:2rem 1rem; display:flex; flex-direction:column; justify-content:space-between;">
    <div>
      <h2 style="font-family:'Sigmar One',cursive; text-align:center; margin-bottom:2rem;">Admin Panel</h2>
      <nav style="display:flex; flex-direction:column; gap:1rem;">
        <a href="{{ route('admin.dashboard') }}"   style="color:white; font-weight:bold;">Dashboard</a>
        <a href="{{ route('admin.users.index') }}" style="color:white;">Gebruikers</a>
        <a href="{{ route('admin.faq.index') }}"   style="color:white;">FAQ</a>
        <a href="{{ route('admin.news.index') }}"  style="color:white;">Nieuws</a>
        <a href="{{ route('admin.contact.inbox') }}" style="color:white;">Contacten</a>
      </nav>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button style="width:100%; background:#F6E27F; color:#8B0000; padding:0.5rem; border:none; border-radius:5px; cursor:pointer;">
        Uitloggen
      </button>
    </form>
  </aside>

  {{-- Main content --}}
  <main style="flex:1; padding:2rem; overflow-y:auto;">
    <h1 style="color:#8B0000;">Bestellingen</h1>

    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
      <thead style="background:#ffeaea;">
        <tr>
          <th style="padding:0.75rem; text-align:left;">Order ID</th>
          <th style="padding:0.75rem; text-align:left;">Gebruiker</th>
          <th style="padding:0.75rem; text-align:left;">Details</th>
          <th style="padding:0.75rem; text-align:left;">Datum</th>
          <th style="padding:0.75rem; text-align:left;">Acties</th>
        </tr>
      </thead>
      <tbody>
        @foreach($orders as $order)
        <tr style="border-bottom:1px solid #ccc;">
          <td style="padding:0.75rem;">{{ $order->id }}</td>
          <td style="padding:0.75rem;">{{ $order->user->name }}</td>
          <td style="padding:0.75rem;">{{ Str::limit($order->details,40) }}</td>
          <td style="padding:0.75rem;">{{ $order->created_at->format('d-m-Y') }}</td>
          <td style="padding:0.75rem;">
            <form method="POST" action="{{ route('admin.orders.destroy', $order) }}" style="display:inline;">
              @csrf @method('DELETE')
              <button type="submit">Verwijder</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </main>
</body>
</html>
