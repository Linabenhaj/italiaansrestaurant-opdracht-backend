<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard – Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0; font-family:'Outfit',sans-serif; display:flex; height:100vh; background:#FFF7D4;">
  {{-- Sidebar --}}
  <aside style="width:220px; background:#8B0000; color:#fff; padding:2rem 1rem; display:flex; flex-direction:column; justify-content:space-between;">
    <div>
      <h2 style="font-family:'Sigmar One',cursive; text-align:center; margin-bottom:2rem;">Admin Panel</h2>
      <nav style="display:flex; flex-direction:column; gap:1rem;">
        <a href="{{ route('admin.dashboard') }}"   style="color:white; font-weight:bold;">Dashboard</a>
        <a href="{{ route('admin.users.index') }}" style="color:white;">Gebruikers</a>
        <a href="{{ route('admin.faq.index') }}"   style="color:white;">FAQ</a>
        <a href="{{ route('admin.news.index') }}"  style="color:white;">Nieuws</a>
      <a href="{{ route('admin.orders.index') }}" style="color:white;">Bestellingen</a>
        <a href="{{ route('admin.contact.inbox') }}" style="color:white;">Contact</a>
      </nav>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button style="width:100%; background:#F6E27F; color:#8B0000; padding:0.5rem; border:none; border-radius:5px; cursor:pointer;">
        Uitloggen
      </button>
    </form>
  </aside>

  {{-- Main content --}}
  <main style="flex:1; padding:2rem; overflow-y:auto;">
    <h1 style="color:#8B0000;">Welkom, {{ $admin->name }}</h1>
    <p style="color:#555;">Ingelogd als: {{ $admin->email }}</p>

    <section style="margin-top:2rem; display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:1rem;">
      <div style="background:#ffeaea; padding:1rem; border-radius:10px;">
        <h3>Totaal gebruikers</h3>
        <p style="font-size:1.5rem;">{{ $userCount }}</p>
      </div>
      <div style="background:#fff4d6; padding:1rem; border-radius:10px;">
        <h3>Openstaande vragen</h3>
        <p style="font-size:1.5rem;">{{ $pendingFaqs }}</p>
      </div>
      <div style="background:#eaffea; padding:1rem; border-radius:10px;">
        <h3>Contactberichten</h3>
        <p style="font-size:1.5rem;">{{ $contactCount }}</p>
      </div>
    </section>
  </main>
</body>
</html>
