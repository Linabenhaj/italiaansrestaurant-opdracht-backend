<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Gebruikersdashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0; font-family:'Outfit', sans-serif; background-color:#fff;">

<header style="background-color:#8B0000; color:#fff; padding:1rem; text-align:center;">
    <h1 style="margin:0; font-family:'Sigmar One', cursive;">Dashboard Gebruiker</h1>
</header>

<nav style="background-color:rgb(255,207,207); padding:1rem;">
    <div style="max-width:1200px; margin:0 auto; display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:2rem;">
            <img src="{{ asset('images/pizzerialogo.png') }}" alt="Logo" style="height:80px;">
            <a href="{{ url('/') }}" style="color:#8B0000; font-weight:bold; text-decoration:none;">Home</a>
            <a href="{{ route('profile.edit', $user->username) }}" style="color:#8B0000; text-decoration:none;">Profiel bewerken</a>
        </div>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button style="background-color:#8B0000; color:#fff; border:none; padding:0.5rem 1rem; cursor:pointer;">Uitloggen</button>
        </form>
    </div>
</nav>
@extends('layouts.user')

@section('title','Dashboard Gebruiker')

@section('content')
  <section>…hier jouw dashboard…</section>
@endsection

<section style="padding:2rem; max-width:600px; margin:2rem auto; background:#fff4f4; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.1);">
    <h2 style="color:#8B0000; margin-bottom:1rem;">Welkom, {{ $user->username ?? $user->name }}</h2>

    @if($user->profile_picture)
        <p><strong>Profielfoto:</strong></p>
        <img src="{{ asset('storage/'.$user->profile_picture) }}" alt="Profielfoto" style="max-width:150px; border-radius:10px; margin-bottom:1rem;">
    @else
        <p><em>Geen profielfoto ingesteld.</em></p>
    @endif

    <p><strong>Email:</strong> {{ $user->email }}</p>
    <p><strong>Geboortedatum:</strong> {{ $user->birthday ?? 'Niet opgegeven' }}</p>
    <p><strong>Over mij:</strong> {{ $user->about ?? 'Geen info' }}</p>
</section>

<footer style="background-color:#8B0000; color:#fff; padding:2rem 1rem; text-align:center; font-size:0.9rem;">
    © 2025 Pizzeria Antonio | Alle rechten voorbehouden
</footer>

</body>
</html>
