<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Profiel bewerken</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0; font-family:'Outfit', sans-serif; background-color:#fff7d4;">

<header style="background-color:#8B0000; color:#fff; padding:1rem; text-align:center;">
    <h1 style="margin:0; font-family:'Sigmar One', cursive;">Profiel bewerken</h1>
</header>

<nav style="background-color:rgb(255, 207, 207); padding:1rem;">
    <div style="max-width:1200px; margin:0 auto; display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:2rem;">
            <img src="{{ asset('images/pizzerialogo.png') }}" alt="Logo" style="height:80px;">
            <a href="{{ url('/dashboard') }}" style="color:#8B0000; font-weight:bold; text-decoration:none;">Dashboard</a>
        </div>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button style="background-color:#8B0000; color:#fff; border:none; padding:0.5rem 1rem; cursor:pointer;">Uitloggen</button>
        </form>
    </div>
</nav>

<section style="padding:2rem; max-width:600px; margin:2rem auto; background:#fff; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.1);">
    @if(session('success'))
        <div style="background-color:#d4edda; color:#155724; padding:1rem; border-radius:5px; margin-bottom:1rem;">
            {{ session('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('profile.update', ['username' => $user->username]) }}">
        @csrf
        @method('PUT')

        <label for="username" style="display:block; margin-bottom:0.3rem; color:#8B0000;">Gebruikersnaam</label>
        <input id="username" name="username" value="{{ old('username', $user->username) }}" required maxlength="255" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">
        @error('username')
            <div style="color:red; margin-bottom:1rem;">{{ $message }}</div>
        @enderror

        <label for="email" style="display:block; margin-bottom:0.3rem; color:#8B0000;">E-mailadres</label>
        <input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" required maxlength="255" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">
        @error('email')
            <div style="color:red; margin-bottom:1rem;">{{ $message }}</div>
        @enderror

        <label for="password" style="display:block; margin-bottom:0.3rem; color:#8B0000;">Wachtwoord (leeg laten om niet te wijzigen)</label>
        <input id="password" type="password" name="password" autocomplete="new-password" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">
        @error('password')
            <div style="color:red; margin-bottom:1rem;">{{ $message }}</div>
        @enderror

        <label for="password_confirmation" style="display:block; margin-bottom:0.3rem; color:#8B0000;">Bevestig wachtwoord</label>
        <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">

        <label for="birthday" style="display:block; margin-bottom:0.3rem; color:#8B0000;">Geboortedatum</label>
        <input id="birthday" type="date" name="birthday" value="{{ old('birthday', $user->birthday ? $user->birthday->format('Y-m-d') : '') }}" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">
        @error('birthday')
            <div style="color:red; margin-bottom:1rem;">{{ $message }}</div>
        @enderror

        <label for="about" style="display:block; margin-bottom:0.3rem; color:#8B0000;">Over mij</label>
        <textarea id="about" name="about" rows="4" style="width:100%; padding:0.5rem; margin-bottom:1rem; border:1px solid #ccc; border-radius:5px;">{{ old('about', $user->about) }}</textarea>
        @error('about')
            <div style="color:red; margin-bottom:1rem;">{{ $message }}</div>
        @enderror

        <button type="submit" style="background-color:#8B0000; color:#fff; border:none; padding:0.75rem 1.5rem; border-radius:5px; cursor:pointer;">Opslaan</button>
    </form>
</section>

<footer style="background-color:#8B0000; color:#fff; padding:2rem 1rem; text-align:center; font-size:0.9rem;">
    © 2025 Pizzeria Antonio | Alle rechten voorbehouden | Design door: Lina Benhaj
</footer>

</body>
</html>
