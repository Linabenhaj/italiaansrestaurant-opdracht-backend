<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Profiel bewerken - Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin: 0; font-family: 'Outfit', sans-serif; background-color: #FFF7D4;">

<header style="background-color: #8B0000; color: white; padding: 1rem; text-align: center;">
    <h1 style="margin: 0; font-family: 'Sigmar One', cursive;">Profiel bewerken</h1>
</header>

<nav style="background-color: rgb(255, 207, 207); padding: 1rem;">
    <div style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center;">
        <a href="{{ route('user.dashboard') }}" style="color: #8B0000; text-decoration: none;">← Terug naar Dashboard</a>
        <form method="POST" action="{{ route('logout') }}" style="margin: 0;">
            @csrf
            <button type="submit" style="background-color: #8B0000; color: white; border: none; padding: 0.5rem 1rem; cursor: pointer;">Uitloggen</button>
        </form>
    </div>
</nav>

<main style="max-width: 600px; margin: 3rem auto; background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
    @if(session('success'))
        <div style="background-color: #d4edda; color: #155724; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div style="background-color: #f8d7da; color: #721c24; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
            <ul style="margin: 0; padding-left: 1.2rem;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('profile.update', ['username' => $user->username]) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <label for="username" style="display:block; margin-bottom: 0.5rem; color: #8B0000;">Gebruikersnaam</label>
        <input type="text" id="username" name="username" value="{{ old('username', $user->username) }}" required style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;">

        <label for="email" style="display:block; margin-bottom: 0.5rem; color: #8B0000;">E-mailadres</label>
        <input type="email" id="email" name="email" value="{{ old('email', $user->email) }}" required style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;">

        <label for="birthday" style="display:block; margin-bottom: 0.5rem; color: #8B0000;">Geboortedatum</label>
        <input type="date" id="birthday" name="birthday" value="{{ old('birthday', optional($user->birthday)->format('Y-m-d')) }}" style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;">

        <label for="about" style="display:block; margin-bottom: 0.5rem; color: #8B0000;">Over mij</label>
        <textarea id="about" name="about" rows="4" style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;">{{ old('about', $user->about) }}</textarea>

        <label for="profile_picture" style="display:block; margin-bottom: 0.5rem; color: #8B0000;">Profielfoto uploaden</label>
        <input type="file" id="profile_picture" name="profile_picture" accept="image/*" style="margin-bottom: 1.5rem;">

        <button type="submit" style="background-color: #8B0000; color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 5px; cursor: pointer;">Opslaan</button>
    </form>
</main>

<footer style="background-color: #8B0000; color: white; padding: 2rem 1rem; text-align: center; font-family: 'Outfit', sans-serif;">
    <p>© 2025 Pizzeria Antonio | Alle rechten voorbehouden | Design door: Lina Benhaj</p>
</footer>

</body>
</html>
