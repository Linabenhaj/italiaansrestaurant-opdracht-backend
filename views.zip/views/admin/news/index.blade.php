<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Beheer Nieuws</title>
  <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0;font-family:'Outfit',sans-serif;display:flex;height:100vh;background:#FFF7D4;">

  {{-- Sidebar (hergebruik je admin-panel uit dashboard.blade) --}}
  @include('admin._sidebar')

  <main style="flex:1;padding:2rem;overflow-y:auto;">
    <h1 style="color:#8B0000;">Nieuwsbeheer</h1>
    <a href="{{ route('admin.news.create') }}"
       style="background:#4CAF50;color:white;padding:0.5rem 1rem;border-radius:5px;text-decoration:none;">
      + Nieuw Nieuwsitem
    </a>
    @if(session('success'))
      <div style="margin:1rem 0;padding:0.5rem;background:#d4edda;color:#155724;border-radius:5px;">
        {{ session('success') }}
      </div>
    @endif

    <table style="width:100%;border-collapse:collapse;margin-top:1rem;">
      <thead>
        <tr style="background:#ffeaea;">
          <th style="padding:.75rem;text-align:left;">Titel</th>
          <th style="padding:.75rem;text-align:left;">Datum</th>
          <th style="padding:.75rem;text-align:left;">Acties</th>
        </tr>
      </thead>
      <tbody>
        @foreach($newsItems as $item)
        <tr style="border-bottom:1px solid #ccc;">
          <td style="padding:.75rem;">{{ $item->title }}</td>
          <td style="padding:.75rem;">{{ $item->published_at->format('d-m-Y') }}</td>
          <td style="padding:.75rem;">
            <a href="{{ route('admin.news.edit',$item) }}">Wijzigen</a>
            <form action="{{ route('admin.news.destroy',$item) }}" method="POST" style="display:inline;">
              @csrf @method('DELETE')
              <button style="background:none;border:none;color:#c00;cursor:pointer;">Verwijderen</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </main>
</body>
</html>
