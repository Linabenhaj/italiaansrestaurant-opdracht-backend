<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Nieuw Nieuwsitem</title>
  <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0;font-family:'Outfit',sans-serif;display:flex;height:100vh;background:#FFF7D4;">

  @include('admin._sidebar')

  <main style="flex:1;padding:2rem;overflow-y:auto;">
    <h1 style="color:#8B0000;">Nieuw Nieuwsitem</h1>
    <form action="{{ route('admin.news.store') }}" method="POST" enctype="multipart/form-data" style="max-width:600px;">
      @csrf
      <label>Titel</label>
      <input type="text" name="title" required style="width:100%;margin-bottom:1rem;padding:.5rem;border-radius:5px;">
      <label>Afbeelding</label>
      <input type="file" name="image" required style="margin-bottom:1rem;">
      <label>Inhoud</label>
      <textarea name="content" rows="5" required style="width:100%;margin-bottom:1rem;padding:.5rem;border-radius:5px;"></textarea>
      <label>Publicatiedatum</label>
      <input type="date" name="published_at" required style="margin-bottom:1rem;padding:.5rem;border-radius:5px;">
      <button type="submit" style="background:#8B0000;color:white;padding:.75rem 1.5rem;border:none;border-radius:5px;cursor:pointer;">
        Opslaan
      </button>
    </form>
  </main>
</body>
</html>
