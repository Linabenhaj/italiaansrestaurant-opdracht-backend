<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Nieuwe gebruiker – Admin Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
  <style>
    body { margin:0; font-family:'Outfit',sans-serif; }
    label { display:block; margin-bottom:0.75rem; }
    input, button { padding:0.5rem; border:1px solid #ccc; border-radius:4px; width:100%; }
    button { background:#8B0000; color:#fff; border:none; cursor:pointer; margin-top:1rem; }
    .sidebar { width:220px; background:#8B0000; color:#fff; padding:2rem; position:fixed; height:100vh; }
    .main   { margin-left:240px; padding:2rem; max-width:600px; }
    nav a { color:#fff; text-decoration:none; display:block; margin-bottom:0.5rem; }
  </style>
</head>
<body>

  <aside class="sidebar">
    <h2 style="font-weight:normal; margin-bottom:1.5rem;">Admin Panel</h2>
    <nav>
      <a href="{{ route('admin.dashboard') }}">Dashboard</a>
      <a href="{{ route('admin.users.index') }}">Gebruikers</a>
      <a href="{{ route('admin.faq.index') }}">FAQ</a>
      <a href="{{ route('admin.news.index') }}">Nieuws</a>
      <a href="{{ route('admin.contact.inbox') }}">Contacten</a>
      <form method="POST" action="{{ route('logout') }}" style="margin-top:2rem;">@csrf
        <button type="submit">Uitloggen</button>
      </form>
    </nav>
  </aside>

  <main class="main">
    <h1>Nieuwe gebruiker</h1>
    <form method="POST" action="{{ route('admin.users.store') }}">
      @csrf

      <label>
        Naam
        <input type="text" name="name" required>
      </label>

      <label>
        Email
        <input type="email" name="email" required>
      </label>

      <label>
        Wachtwoord
        <input type="password" name="password" required>
      </label>

      <label>
        Bevestig wachtwoord
        <input type="password" name="password_confirmation" required>
      </label>

      <label style="display:flex; align-items:center;">
        <input type="checkbox" name="is_admin" style="width:auto; margin-right:0.5rem;">
        Adminrechten geven
      </label>

      <button type="submit">Opslaan</button>
    </form>
  </main>

</body>
</html>
