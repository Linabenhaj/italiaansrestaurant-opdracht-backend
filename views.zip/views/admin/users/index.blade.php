<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Gebruikersbeheer – Pizzeria Antonio</title>
    <link href="https://fonts.googleapis.com/css2?family=Sigmar+One&family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body style="margin:0; font-family:'Outfit',sans-serif; display:flex; height:100vh; background:#FFF7D4;">

  {{-- Sidebar --}}
  <aside style="width:220px; background:#8B0000; color:#fff; padding:2rem 1rem; display:flex; flex-direction:column; justify-content:space-between;">
    <div>
      <h2 style="font-family:'Sigmar One',cursive; text-align:center; margin-bottom:2rem;">Admin Panel</h2>
      <nav style="display:flex; flex-direction:column; gap:1rem;">
        <a href="{{ route('admin.dashboard') }}"   style="color:white; font-weight:bold;">Dashboard</a>
        <a href="{{ route('admin.users.index') }}" style="color:white;">Gebruikers</a>
        <a href="{{ route('admin.faq.index') }}"   style="color:white;">FAQ</a>
        <a href="{{ route('admin.news.index') }}"  style="color:white;">Nieuws</a>
        <a href="{{ route('admin.contact.inbox') }}" style="color:white;">Contacten</a>
      </nav>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button style="width:100%; background:#F6E27F; color:#8B0000; padding:0.5rem; border:none; border-radius:5px; cursor:pointer;">
        Uitloggen
      </button>
    </form>
  </aside>

  {{-- Main content --}}
  <main style="flex:1; padding:2rem; overflow-y:auto;">
    <h1 style="color:#8B0000;">Gebruikersbeheer</h1>
    <p style="color:#555;">Hieronder zie je alle gebruikers en kun je beheren:</p>

    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
      <thead style="background:#ffeaea;">
        <tr>
          <th style="padding:0.75rem; text-align:left;">ID</th>
          <th style="padding:0.75rem; text-align:left;">Naam</th>
          <th style="padding:0.75rem; text-align:left;">E-mail</th>
          <th style="padding:0.75rem; text-align:left;">Admin?</th>
          <th style="padding:0.75rem; text-align:left;">Acties</th>
        </tr>
      </thead>
      <tbody>
        @foreach($users as $user)
        <tr style="border-bottom:1px solid #ccc;">
          <td style="padding:0.75rem;">{{ $user->id }}</td>
          <td style="padding:0.75rem;">{{ $user->name }}</td>
          <td style="padding:0.75rem;">{{ $user->email }}</td>
          <td style="padding:0.75rem;">{{ $user->is_admin ? 'Ja' : 'Nee' }}</td>
          <td style="padding:0.75rem;">
            @if(!$user->is_admin)
              <form method="POST" action="{{ route('admin.users.promote', $user) }}" style="display:inline;">
                @csrf<button type="submit" style="margin-right:0.5rem;">Promoveer</button>
              </form>
            @else
              <form method="POST" action="{{ route('admin.users.demote', $user) }}" style="display:inline;">
                @csrf<button type="submit" style="margin-right:0.5rem;">Degradeer</button>
              </form>
            @endif
            <form method="POST" action="{{ route('admin.users.destroy', $user) }}" style="display:inline;">
              @csrf @method('DELETE')
              <button type="submit">Verwijder</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </main>
</body>
</html>
