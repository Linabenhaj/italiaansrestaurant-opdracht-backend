<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>FAQ Vraag Toevoegen</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="container mt-5">
        <h1>Nieuwe FAQ-vraag toevoegen</h1>

        <form action="{{ route('admin.faq.store') }}" method="POST">
            @csrf

            <div class="mb-3">
                <label for="question" class="form-label">Vraag</label>
                <input type="text" name="question" id="question" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="answer" class="form-label">Antwoord</label>
                <textarea name="answer" id="answer" class="form-control" rows="4" required></textarea>
            </div>

            <div class="mb-3">
                <label for="faq_category_id" class="form-label">Categorie</label>
                <select name="faq_category_id" id="faq_category_id" class="form-control" required>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                </select>
            </div>

            <button type="submit" class="btn btn-success">Toevoegen</button>
        </form>
    </div>
</body>
</html>
