<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>FAQ Bewerken</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Outfit', sans-serif; margin: 2rem;">
    <h1>FAQ Vraag Bewerken</h1>

    <form action="{{ route('admin.faq.update', $faq->id) }}" method="POST">
        @csrf
        @method('PUT')

        <label for="question">Vraag:</label><br>
        <input type="text" name="question" id="question" value="{{ old('question', $faq->question) }}" required style="width: 100%; margin-bottom: 1rem;">

        <label for="answer">Antwoord:</label><br>
        <textarea name="answer" id="answer" rows="5" required style="width: 100%; margin-bottom: 1rem;">{{ old('answer', $faq->answer) }}</textarea>

        <label for="faq_category_id">Categorie:</label><br>
        <select name="faq_category_id" id="faq_category_id" required style="width: 100%; margin-bottom: 1rem;">
            @foreach($categories as $category)
                <option value="{{ $category->id }}" {{ $faq->faq_category_id == $category->id ? 'selected' : '' }}>
                    {{ $category->name }}
                </option>
            @endforeach
        </select>

        <button type="submit" style="padding: 0.5rem 1rem; background-color: #8B0000; color: white; border: none; cursor: pointer;">Bijwerken</button>
    </form>

    <a href="{{ route('admin.faq.index') }}" style="display: inline-block; margin-top: 1rem;">← Terug naar FAQ overzicht</a>
</body>
</html>
