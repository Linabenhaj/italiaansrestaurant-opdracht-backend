<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>{{ $news->title }} – Pizzeria Antonio</title>
</head>
<body style="font-family:sans-serif;padding:2rem;">
  <h1>{{ $news->title }}</h1>
  <p><em>Gepubliceerd op {{ $news->published_at->format('d-m-Y H:i') }}</em></p>
  <img src="{{ asset('storage/'.$news->image) }}" style="max-width:400px;margin-bottom:1rem;">
  <div>{!! nl2br(e($news->content)) !!}</div>
  <p><a href="{{ route('news.index') }}">← Terug naar nieuws</a></p>
</body>
</html>
