<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Nieuws – Pizzeria Antonio</title>
</head>
<body style="font-family:sans-serif;padding:2rem;">
  <h1>Laatste nieuws</h1>
  @foreach($newsItems as $news)
    <article style="margin-bottom:2rem;">
      <h2><a href="{{ route('news.show',$news) }}">{{ $news->title }}</a></h2>
      <p><em>Gepubliceerd op {{ $news->published_at->format('d-m-Y') }}</em></p>
      <img src="{{ asset('storage/'.$news->image) }}" style="max-width:300px;">
      <p>{{ Str::limit($news->content, 150) }}</p>
      <a href="{{ route('news.show',$news) }}">Lees meer →</a>
    </article>
  @endforeach

  {{ $newsItems->links() }}
</body>
</html>
